export enum TypeMessage {
    new = 'new',
    turnChange = 'turnChange',
    deleteTurn = 'deleteTurn',
    turnPostpone = 'turnPostpone',
    deleteTurnNotification = 'deleteTurnNotification'
  }
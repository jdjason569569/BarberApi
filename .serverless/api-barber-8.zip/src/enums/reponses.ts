export enum Response {
    SUCCESS = "success",
    ERROR = "error",
    SAME_HOUR = "sameHour"
}